import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro


def _configure_nav2_params(template_file, bt_xml_file, map_yaml_file):
    """Genera un YAML temporal sin rutas absolutas hardcodeadas."""
    with open(template_file, 'r', encoding='utf-8') as f:
        text = f.read()

    text = text.replace('__BT_XML__', bt_xml_file)
    text = text.replace('__MAP_YAML__', map_yaml_file)

    output_file = '/tmp/robot_rescue_nav_nav2_params.yaml'
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(text)

    return output_file


def generate_launch_description():
    pkg_rescue_nav = get_package_share_directory('robot_rescue_nav')
    pkg_nav2_bringup = get_package_share_directory('nav2_bringup')

    world_file = os.path.join(pkg_rescue_nav, 'worlds', 'multi_sala.world')
    xacro_file = os.path.join(pkg_rescue_nav, 'urdf', 'waffle_custom.urdf.xacro')
    map_yaml_file = os.path.join(pkg_rescue_nav, 'maps', 'multi_sala.yaml')
    nav2_yaml_template = os.path.join(pkg_rescue_nav, 'config', 'nav2_params.yaml')
    bt_xml_file = os.path.join(pkg_rescue_nav, 'behavior_trees', 'arbol.xml')
    rviz_config_file = os.path.join(pkg_rescue_nav, 'rviz', 'rescue_config.rviz')

    # Evita fallos por /home/usuario/...: el YAML temporal queda con rutas reales.
    nav2_yaml_file = _configure_nav2_params(nav2_yaml_template, bt_xml_file, map_yaml_file)

    # Robot description desde Xacro
    doc = xacro.process_file(xacro_file)
    robot_description = {'robot_description': doc.toxml()}

    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description, {'use_sim_time': True}]
    )

    gazebo = ExecuteProcess(
        cmd=[
            'gazebo', '--verbose',
            '-s', 'libgazebo_ros_init.so',
            '-s', 'libgazebo_ros_factory.so',
            world_file
        ],
        output='screen'
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'waffle_rescue', '-topic', 'robot_description'],
        output='screen'
    )

    # Simulador: publica gas, heartbeat, batería, visual y térmico.
    sensor_simulator = Node(
        package='robot_rescue_nav',
        executable='sensor_simulator.py',
        name='sensor_simulator',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'heartbeat_value': 'Control_Center_OK',
            'normal_gas_value': 'NORMAL',
            'critical_gas_value': 'CRITICO',
        }]
    )

    # CORRECCIÓN CLAVE: monitor independiente del BT.
    # Este nodo escucha sensores SIEMPRE, aun cuando Nav2 no tenga goal activo.
    rescue_safety_monitor = Node(
        package='robot_rescue_nav',
        executable='rescue_safety_monitor.py',
        name='rescue_safety_monitor',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'gas_threshold': 50.0,
            'battery_min': 0.20,
            'heartbeat_timeout_sec': 3.0,
            'sensor_timeout_sec': 2.5,
            'startup_grace_sec': 8.0,
            'base_x': 0.0,
            'base_y': 0.0,
            'base_yaw': 0.0,
        }]
    )

    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_nav2_bringup, 'launch', 'bringup_launch.py')),
        launch_arguments={
            'map': map_yaml_file,
            'use_sim_time': 'true',
            'params_file': nav2_yaml_file,
            'autostart': 'true',
            'default_nav_to_pose_bt_xml': bt_xml_file,
            'default_nav_through_poses_bt_xml': bt_xml_file,
        }.items()
    )

    rviz2 = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    # Secuencia de arranque.
    # 1) Gazebo y robot_state_publisher.
    # 2) Spawn del robot.
    # 3) Sensores.
    # 4) Monitor de seguridad permanente.
    # 5) Nav2.
    # 6) RViz.
    delayed_spawn_entity = TimerAction(period=8.0, actions=[spawn_entity])
    delayed_sensor_simulator = TimerAction(period=12.0, actions=[sensor_simulator])
    delayed_safety_monitor = TimerAction(period=14.0, actions=[rescue_safety_monitor])
    delayed_nav2_bringup = TimerAction(period=18.0, actions=[nav2_bringup])
    delayed_rviz2 = TimerAction(period=35.0, actions=[rviz2])

    return LaunchDescription([
        node_robot_state_publisher,
        gazebo,
        delayed_spawn_entity,
        delayed_sensor_simulator,
        delayed_safety_monitor,
        delayed_nav2_bringup,
        delayed_rviz2,
    ])
