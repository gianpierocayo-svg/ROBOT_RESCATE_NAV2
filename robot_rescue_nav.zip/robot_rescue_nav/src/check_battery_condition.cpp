#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/condition_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "sensor_msgs/msg/battery_state.hpp"

namespace robot_rescue_nav
{

/**
 * Regla 3: batería crítica.
 *
 * SUCCESS significa: batería baja.
 * FAILURE significa: batería suficiente o aún sin primera lectura inicial.
 *
 * Este plugin usa su propio nodo rclcpp y spin_some() en cada tick para que
 * el mensaje de /battery_status llegue realmente al árbol.
 */
class CheckBatteryCondition : public BT::ConditionNode
{
public:
  CheckBatteryCondition(const std::string & name, const BT::NodeConfiguration & config)
  : BT::ConditionNode(name, config),
    battery_topic_("/battery_status"),
    min_battery_(0.20),
    is_voltage_(false),
    data_timeout_(5.0),
    percentage_(1.0),
    voltage_(12.6),
    has_reading_(false)
  {
    const auto id = instance_counter_++;
    node_ = rclcpp::Node::make_shared(
      "check_battery_condition_bt_node_" + std::to_string(id));

    getInput("battery_topic", battery_topic_);
    getInput("min_battery", min_battery_);
    getInput("is_voltage", is_voltage_);
    getInput("data_timeout", data_timeout_);

    if (data_timeout_ <= 0.0) {
      data_timeout_ = 5.0;
    }

    battery_sub_ = node_->create_subscription<sensor_msgs::msg::BatteryState>(
      battery_topic_,
      10,
      std::bind(&CheckBatteryCondition::batteryCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckBatteryCondition] Suscrito a '%s' | umbral bajo: %.2f%s",
      battery_topic_.c_str(), min_battery_, is_voltage_ ? "V" : " (fracción)");
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>(
        "battery_topic",
        std::string("/battery_status"),
        "Tópico de estado de batería"),
      BT::InputPort<double>(
        "min_battery",
        0.20,
        "Umbral bajo: <20% dispara recuperación"),
      BT::InputPort<bool>(
        "is_voltage",
        false,
        "true: comparar contra voltaje; false: contra percentage normalizado 0-1"),
      BT::InputPort<double>(
        "data_timeout",
        5.0,
        "Segundos sin dato antes de considerar dato vencido")
    };
  }

  BT::NodeStatus tick() override
  {
    rclcpp::spin_some(node_);

    std::lock_guard<std::mutex> lock(mutex_);

    if (!has_reading_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckBatteryCondition] Aún sin lectura de /battery_status. No se activa batería crítica desde el BT.");
      return BT::NodeStatus::FAILURE;
    }

    const double age = (node_->now() - last_msg_time_).seconds();
    if (age > data_timeout_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckBatteryCondition] Dato vencido de /battery_status (%.2fs). No se activa batería crítica desde el BT.",
        age);
      return BT::NodeStatus::FAILURE;
    }

    const double current_value = is_voltage_ ? voltage_ : percentage_;

    RCLCPP_INFO_THROTTLE(
      node_->get_logger(), *node_->get_clock(), 2000,
      "[CheckBatteryCondition] Leyendo /battery_status: %.2f (umbral %.2f)",
      current_value, min_battery_);

    if (current_value < min_battery_) {
      RCLCPP_WARN(
        node_->get_logger(),
        "[CheckBatteryCondition] BATERÍA BAJA: %.2f (umbral %.2f)",
        current_value, min_battery_);
      return BT::NodeStatus::SUCCESS;
    }

    return BT::NodeStatus::FAILURE;
  }

private:
  void batteryCallback(const sensor_msgs::msg::BatteryState::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);

    const double raw_percentage = static_cast<double>(msg->percentage);
    percentage_ = (raw_percentage > 1.0) ? (raw_percentage / 100.0) : raw_percentage;
    voltage_ = static_cast<double>(msg->voltage);

    // Si llega un BatteryState incompleto con 0.0 y present=false, no lo tratamos
    // como batería válida porque produce falsos giros de emergencia.
    if (!msg->present && raw_percentage <= 0.0 && voltage_ <= 0.0) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckBatteryCondition] BatteryState incompleto ignorado: present=false, percentage=0, voltage=0.");
      return;
    }

    last_msg_time_ = node_->now();
    has_reading_ = true;
  }

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<sensor_msgs::msg::BatteryState>::SharedPtr battery_sub_;

  std::string battery_topic_;
  double min_battery_;
  bool is_voltage_;
  double data_timeout_;

  double percentage_;
  double voltage_;
  bool has_reading_;
  rclcpp::Time last_msg_time_;
  std::mutex mutex_;

  static std::atomic_uint32_t instance_counter_;
};

std::atomic_uint32_t CheckBatteryCondition::instance_counter_{0};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::CheckBatteryCondition>("CheckBatteryCondition");
  }
}
