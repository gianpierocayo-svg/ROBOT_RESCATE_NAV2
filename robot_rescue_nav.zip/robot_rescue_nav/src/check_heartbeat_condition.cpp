#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/condition_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "std_msgs/msg/string.hpp"

namespace robot_rescue_nav
{

/**
 * Regla 2: pérdida de enlace.
 *
 * SUCCESS significa: enlace perdido.
 * FAILURE significa: enlace activo o aún sin primera lectura inicial.
 *
 * Se usa nodo rclcpp propio + spin_some() en tick para procesar el heartbeat
 * dentro del plugin BT. Si nunca llegó heartbeat, NO se dispara emergencia
 * desde el BT; el monitor externo rescue_safety_monitor.py se encarga de la
 * vigilancia permanente fuera de Nav2.
 */
class CheckHeartbeatCondition : public BT::ConditionNode
{
public:
  CheckHeartbeatCondition(const std::string & name, const BT::NodeConfiguration & config)
  : BT::ConditionNode(name, config),
    heartbeat_topic_("/heartbeat"),
    timeout_sec_(3.0),
    startup_grace_sec_(8.0),
    received_first_msg_(false)
  {
    const auto id = instance_counter_++;
    node_ = rclcpp::Node::make_shared(
      "check_heartbeat_condition_bt_node_" + std::to_string(id));

    getInput("heartbeat_topic", heartbeat_topic_);
    getInput("timeout_sec", timeout_sec_);
    getInput("startup_grace_sec", startup_grace_sec_);

    if (timeout_sec_ <= 0.0) {
      timeout_sec_ = 3.0;
    }

    heartbeat_sub_ = node_->create_subscription<std_msgs::msg::String>(
      heartbeat_topic_,
      10,
      std::bind(&CheckHeartbeatCondition::heartbeatCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckHeartbeatCondition] Suscrito a '%s' | timeout: %.2fs",
      heartbeat_topic_.c_str(), timeout_sec_);
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>(
        "heartbeat_topic",
        std::string("/heartbeat"),
        "Tópico de heartbeat del Centro de Control"),
      BT::InputPort<double>(
        "timeout_sec",
        3.0,
        "Segundos sin señal para considerar enlace perdido"),
      BT::InputPort<double>(
        "startup_grace_sec",
        8.0,
        "Tiempo de gracia inicial informativo")
    };
  }

  BT::NodeStatus tick() override
  {
    rclcpp::spin_some(node_);

    std::lock_guard<std::mutex> lock(mutex_);

    if (!received_first_msg_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckHeartbeatCondition] Aún sin primera lectura de /heartbeat. No se activa pérdida de enlace desde el BT.");
      return BT::NodeStatus::FAILURE;
    }

    const double age = (node_->now() - last_msg_time_).seconds();
    if (age > timeout_sec_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 1000,
        "[CheckHeartbeatCondition] Enlace perdido hace %.2fs (timeout %.2fs).",
        age, timeout_sec_);
      return BT::NodeStatus::SUCCESS;
    }

    RCLCPP_INFO_THROTTLE(
      node_->get_logger(), *node_->get_clock(), 2000,
      "[CheckHeartbeatCondition] Leyendo /heartbeat: enlace activo.");
    return BT::NodeStatus::FAILURE;
  }

private:
  void heartbeatCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    if (msg->data.empty()) {
      return;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    last_msg_time_ = node_->now();

    if (!received_first_msg_) {
      received_first_msg_ = true;
      RCLCPP_INFO(
        node_->get_logger(),
        "[CheckHeartbeatCondition] Primer heartbeat recibido: '%s' — enlace activo",
        msg->data.c_str());
    }
  }

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr heartbeat_sub_;

  std::string heartbeat_topic_;
  double timeout_sec_;
  double startup_grace_sec_;

  rclcpp::Time last_msg_time_;
  bool received_first_msg_;
  std::mutex mutex_;

  static std::atomic_uint32_t instance_counter_;
};

std::atomic_uint32_t CheckHeartbeatCondition::instance_counter_{0};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::CheckHeartbeatCondition>("CheckHeartbeatCondition");
  }
}
