#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/condition_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "std_msgs/msg/bool.hpp"

namespace robot_rescue_nav
{

class CheckVisualCondition : public BT::ConditionNode
{
public:
  CheckVisualCondition(const std::string & name, const BT::NodeConfiguration & config)
  : BT::ConditionNode(name, config),
    detection_topic_("/detected_people"),
    data_timeout_(2.0),
    person_detected_(false),
    has_reading_(false)
  {
    const auto id = instance_counter_++;
    node_ = rclcpp::Node::make_shared(
      "check_visual_condition_bt_node_" + std::to_string(id));

    getInput("detection_topic", detection_topic_);
    getInput("data_timeout", data_timeout_);

    vis_sub_ = node_->create_subscription<std_msgs::msg::Bool>(
      detection_topic_,
      10,
      std::bind(&CheckVisualCondition::visualCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckVisualCondition] Suscrito a '%s'", detection_topic_.c_str());
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>(
        "detection_topic",
        std::string("/detected_people"),
        "Tópico de detección visual"),
      BT::InputPort<double>(
        "data_timeout",
        2.0,
        "Segundos sin dato antes de considerarlo obsoleto")
    };
  }

  BT::NodeStatus tick() override
  {
    rclcpp::spin_some(node_);

    std::lock_guard<std::mutex> lock(mutex_);

    if (!has_reading_) {
      return BT::NodeStatus::FAILURE;
    }

    const double age = (node_->now() - last_msg_time_).seconds();
    if (age > data_timeout_) {
      return BT::NodeStatus::FAILURE;
    }

    if (person_detected_) {
      RCLCPP_INFO_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 1000,
        "[CheckVisualCondition] Leyendo /detected_people: true -> posible víctima");
      return BT::NodeStatus::SUCCESS;
    }

    return BT::NodeStatus::FAILURE;
  }

private:
  void visualCallback(const std_msgs::msg::Bool::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);
    person_detected_ = msg->data;
    last_msg_time_ = node_->now();
    has_reading_ = true;
  }

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr vis_sub_;

  std::string detection_topic_;
  double data_timeout_;

  bool person_detected_;
  bool has_reading_;
  rclcpp::Time last_msg_time_;
  std::mutex mutex_;

  static std::atomic_uint32_t instance_counter_;
};

std::atomic_uint32_t CheckVisualCondition::instance_counter_{0};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::CheckVisualCondition>("CheckVisualCondition");
  }
}
