#include <memory>
#include <string>
#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/action_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "geometry_msgs/msg/transform_stamped.hpp"

namespace robot_rescue_nav
{

/**
 * @brief Acción final de la Regla 4: una vez confirmada la víctima
 * (visual + térmico positivos), extrae la posición real del robot
 * leyendo el árbol de transformadas TF (map -> base_link) e imprime
 * explícitamente las coordenadas cartesianas (X, Y) en consola.
 *
 * El timeout de lookupTransform se mantiene corto (100ms) para no
 * bloquear el resto del árbol reactivo (gas/heartbeat deben poder
 * seguir evaluándose sin demoras largas en este nodo).
 */
class LogVictimAction : public BT::SyncActionNode
{
public:
  LogVictimAction(const std::string & name, const BT::NodeConfiguration & config)
  : BT::SyncActionNode(name, config),
    global_frame_("map"),
    robot_frame_("base_link"),
    tf_timeout_(0.1)
  {
    node_ = config.blackboard->get<rclcpp::Node::SharedPtr>("node");

    getInput("global_frame", global_frame_);
    getInput("robot_frame", robot_frame_);
    getInput("tf_timeout", tf_timeout_);

    tf_buffer_ = std::make_unique<tf2_ros::Buffer>(node_->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>("global_frame", std::string("map"), "Frame global de referencia"),
      BT::InputPort<std::string>("robot_frame", std::string("base_link"), "Frame del robot"),
      BT::InputPort<double>("tf_timeout", 0.1, "Timeout en segundos para lookupTransform")
    };
  }

  BT::NodeStatus tick() override
  {
    geometry_msgs::msg::TransformStamped transform_stamped;
    try {
      transform_stamped = tf_buffer_->lookupTransform(
        global_frame_, robot_frame_, tf2::TimePointZero,
        tf2::durationFromSec(tf_timeout_));

      const double x = transform_stamped.transform.translation.x;
      const double y = transform_stamped.transform.translation.y;

      RCLCPP_INFO(
        node_->get_logger(),
        "\n========================================\n"
        "VICTIMA CONFIRMADA Y LOCALIZADA EN:\n"
        "Posicion Cartesiana X: %.2f\n"
        "Posicion Cartesiana Y: %.2f\n"
        "========================================",
        x, y);

      return BT::NodeStatus::SUCCESS;
    } catch (const tf2::TransformException & ex) {
      RCLCPP_ERROR(
        node_->get_logger(),
        "[LogVictimAction] Error obteniendo TF '%s' -> '%s': %s",
        global_frame_.c_str(), robot_frame_.c_str(), ex.what());
      return BT::NodeStatus::FAILURE;
    }
  }

private:
  rclcpp::Node::SharedPtr node_;
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;

  std::string global_frame_;
  std::string robot_frame_;
  double tf_timeout_;
};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::LogVictimAction>("LogVictimAction");
  }
}
