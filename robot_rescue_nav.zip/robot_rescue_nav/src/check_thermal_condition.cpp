#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/condition_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "sensor_msgs/msg/image.hpp"

namespace robot_rescue_nav
{

class CheckThermalCondition : public BT::ConditionNode
{
public:
  CheckThermalCondition(const std::string & name, const BT::NodeConfiguration & config)
  : BT::ConditionNode(name, config),
    thermal_topic_("/thermal_sensor"),
    human_temp_min_(200.0),
    human_temp_max_(255.0),
    data_timeout_(2.0),
    thermal_positive_(false),
    has_reading_(false)
  {
    const auto id = instance_counter_++;
    node_ = rclcpp::Node::make_shared(
      "check_thermal_condition_bt_node_" + std::to_string(id));

    getInput("thermal_topic", thermal_topic_);
    getInput("human_temp_min", human_temp_min_);
    getInput("human_temp_max", human_temp_max_);
    getInput("data_timeout", data_timeout_);

    thermal_sub_ = node_->create_subscription<sensor_msgs::msg::Image>(
      thermal_topic_,
      10,
      std::bind(&CheckThermalCondition::thermalCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckThermalCondition] Suscrito a '%s' | rango humano compatible: [%.0f, %.0f]",
      thermal_topic_.c_str(), human_temp_min_, human_temp_max_);
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>(
        "thermal_topic",
        std::string("/thermal_sensor"),
        "Tópico del sensor térmico"),
      BT::InputPort<double>(
        "human_temp_min",
        200.0,
        "Límite inferior de la banda de intensidad humana"),
      BT::InputPort<double>(
        "human_temp_max",
        255.0,
        "Límite superior de la banda de intensidad humana"),
      BT::InputPort<double>(
        "data_timeout",
        2.0,
        "Segundos sin dato antes de considerarlo obsoleto")
    };
  }

  BT::NodeStatus tick() override
  {
    rclcpp::spin_some(node_);

    std::lock_guard<std::mutex> lock(mutex_);

    if (!has_reading_) {
      return BT::NodeStatus::FAILURE;
    }

    const double age = (node_->now() - last_msg_time_).seconds();
    if (age > data_timeout_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckThermalCondition] Datos de '%s' obsoletos (%.2fs)",
        thermal_topic_.c_str(), age);
      return BT::NodeStatus::FAILURE;
    }

    if (thermal_positive_) {
      RCLCPP_INFO_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 1000,
        "[CheckThermalCondition] Leyendo /thermal_sensor: firma térmica positiva");
      return BT::NodeStatus::SUCCESS;
    }

    return BT::NodeStatus::FAILURE;
  }

private:
  void thermalCallback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);

    if (msg->encoding != "mono8" && msg->encoding != "8UC1") {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 5000,
        "[CheckThermalCondition] Encoding no soportado '%s' (se esperaba mono8/8UC1)",
        msg->encoding.c_str());
      return;
    }

    bool found_human_range = false;
    for (uint8_t pixel_value : msg->data) {
      if (pixel_value >= human_temp_min_ && pixel_value <= human_temp_max_) {
        found_human_range = true;
        break;
      }
    }

    thermal_positive_ = found_human_range;
    last_msg_time_ = node_->now();
    has_reading_ = true;
  }

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr thermal_sub_;

  std::string thermal_topic_;
  double human_temp_min_;
  double human_temp_max_;
  double data_timeout_;

  bool thermal_positive_;
  bool has_reading_;
  rclcpp::Time last_msg_time_;
  std::mutex mutex_;

  static std::atomic_uint32_t instance_counter_;
};

std::atomic_uint32_t CheckThermalCondition::instance_counter_{0};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::CheckThermalCondition>("CheckThermalCondition");
  }
}
