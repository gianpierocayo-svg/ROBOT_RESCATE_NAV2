#include <algorithm>
#include <atomic>
#include <cctype>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "behaviortree_cpp_v3/condition_node.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include "std_msgs/msg/string.hpp"

namespace robot_rescue_nav
{

/**
 * Regla 1: Gas crítico.
 *
 * IMPORTANTE PARA ESTE PROYECTO:
 * - El tópico obligatorio es /sensor_gas_critico.
 * - El tipo obligatorio es std_msgs/msg/String.
 * - SUCCESS significa: hay gas crítico.
 * - FAILURE significa: NO hay gas crítico o aún no hay lectura inicial.
 *
 * Como este nodo está dentro de un Inverter en el XML:
 * - FAILURE -> Inverter -> SUCCESS -> permite navegar.
 * - SUCCESS -> Inverter -> FAILURE -> activa recuperación.
 *
 * Se usa un nodo rclcpp propio y se llama spin_some() en cada tick para que
 * los callbacks de este plugin BT realmente procesen los mensajes recibidos.
 */
class CheckGasCondition : public BT::ConditionNode
{
public:
  CheckGasCondition(const std::string & name, const BT::NodeConfiguration & config)
  : BT::ConditionNode(name, config),
    gas_threshold_(50.0),
    data_timeout_(2.0),
    critical_value_("CRITICO"),
    gas_message_("SIN_DATO"),
    is_critical_(false),
    has_reading_(false)
  {
    const auto id = instance_counter_++;
    node_ = rclcpp::Node::make_shared(
      "check_gas_condition_bt_node_" + std::to_string(id));

    // REQUISITO: el tópico es obligatorio y unificado.
    // Aunque el XML tenga otro valor, se fuerza /sensor_gas_critico.
    gas_topic_ = "/sensor_gas_critico";

    getInput("critical_value", critical_value_);
    getInput("gas_threshold", gas_threshold_);
    getInput("data_timeout", data_timeout_);

    if (critical_value_.empty()) {
      critical_value_ = "CRITICO";
    }
    if (data_timeout_ <= 0.0) {
      data_timeout_ = 2.0;
    }

    gas_sub_ = node_->create_subscription<std_msgs::msg::String>(
      gas_topic_,
      10,
      std::bind(&CheckGasCondition::gasCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckGasCondition] Suscrito OBLIGATORIAMENTE a '%s' | tipo std_msgs/String",
      gas_topic_.c_str());
  }

  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>(
        "gas_topic",
        std::string("/sensor_gas_critico"),
        "Tópico unificado obligatorio del gas crítico"),
      BT::InputPort<std::string>(
        "critical_value",
        std::string("CRITICO"),
        "Texto que representa gas crítico"),
      BT::InputPort<double>(
        "gas_threshold",
        50.0,
        "Umbral opcional si el String contiene un número"),
      BT::InputPort<double>(
        "data_timeout",
        2.0,
        "Segundos sin dato antes de considerar el dato obsoleto")
    };
  }

  BT::NodeStatus tick() override
  {
    // Procesa callbacks pendientes de esta suscripción. Sin esto, el plugin BT
    // puede aparecer suscrito, pero no actualizar sus variables internas.
    rclcpp::spin_some(node_);

    std::lock_guard<std::mutex> lock(mutex_);

    if (!has_reading_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckGasCondition] Aún sin lectura de /sensor_gas_critico. No se activa emergencia desde el BT.");
      return BT::NodeStatus::FAILURE;
    }

    const double age = (node_->now() - last_msg_time_).seconds();
    if (age > data_timeout_) {
      RCLCPP_WARN_THROTTLE(
        node_->get_logger(), *node_->get_clock(), 2000,
        "[CheckGasCondition] Dato vencido de /sensor_gas_critico (%.2fs). Último valor='%s'. No se activa emergencia desde el BT.",
        age, gas_message_.c_str());
      return BT::NodeStatus::FAILURE;
    }

    RCLCPP_INFO_THROTTLE(
      node_->get_logger(), *node_->get_clock(), 1000,
      "[CheckGasCondition] Leyendo /sensor_gas_critico: '%s' -> %s",
      gas_message_.c_str(), is_critical_ ? "GAS CRÍTICO" : "gas normal");

    return is_critical_ ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
  }

private:
  static std::string normalize(std::string value)
  {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
      return static_cast<char>(std::toupper(c));
    });

    const std::string accented = "CRÍTICO";
    if (value == accented) {
      value = "CRITICO";
    }

    value.erase(std::remove_if(value.begin(), value.end(), [](unsigned char c) {
      return std::isspace(c) != 0;
    }), value.end());

    return value;
  }

  bool parseCritical(const std::string & raw) const
  {
    const std::string value = normalize(raw);
    const std::string critical = normalize(critical_value_);

    if (
      value == critical || value == "CRITICO" || value == "CRITICAL" || value == "ALTO" ||
      value == "HIGH" || value == "TRUE" || value == "1" ||
      value == "GAS_CRITICO" || value == "GASCRITICO")
    {
      return true;
    }

    if (value == "NORMAL" || value == "OK" || value == "SEGURO" || value == "FALSE" || value == "0") {
      return false;
    }

    std::istringstream iss(value);
    double numeric_value = 0.0;
    if (iss >> numeric_value) {
      return numeric_value > gas_threshold_;
    }

    return false;
  }

  void gasCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);
    gas_message_ = msg->data;
    is_critical_ = parseCritical(gas_message_);
    last_msg_time_ = node_->now();
    has_reading_ = true;

    RCLCPP_INFO(
      node_->get_logger(),
      "[CheckGasCondition] Recibido /sensor_gas_critico: '%s' -> %s",
      gas_message_.c_str(), is_critical_ ? "CRÍTICO" : "NORMAL");
  }

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr gas_sub_;

  std::string gas_topic_;
  double gas_threshold_;
  double data_timeout_;
  std::string critical_value_;

  std::string gas_message_;
  bool is_critical_;
  bool has_reading_;
  rclcpp::Time last_msg_time_;
  std::mutex mutex_;

  static std::atomic_uint32_t instance_counter_;
};

std::atomic_uint32_t CheckGasCondition::instance_counter_{0};

}  // namespace robot_rescue_nav

extern "C" {
  void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<robot_rescue_nav::CheckGasCondition>("CheckGasCondition");
  }
}
