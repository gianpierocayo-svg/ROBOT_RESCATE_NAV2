#!/usr/bin/env python3
"""
Nodo de seguridad/reactividad permanente para robot de rescate.

Problema que corrige:
- Los nodos de condición del Behavior Tree de Nav2 solo se ejecutan cuando
  existe un goal activo. Si el robot está detenido o Nav2 no está tickeando
  el BT, el robot puede ignorar gas, heartbeat, batería o víctima.

Este nodo corre siempre y escucha los sensores directamente. Ante emergencia:
- Cancela goals activos de Nav2.
- Publica /cmd_vel para detener, retroceder o girar.
- Publica alertas en /rescue/alerts.
- Para batería baja, envía un goal de retorno a base mediante /navigate_to_pose.
"""

from __future__ import annotations

import math
from typing import Optional

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.duration import Duration
from rclpy.time import Time

from action_msgs.srv import CancelGoal
from geometry_msgs.msg import PoseStamped, Twist
from nav2_msgs.action import NavigateToPose
from sensor_msgs.msg import BatteryState, Image
from std_msgs.msg import Bool, String

import tf2_ros


class RescueSafetyMonitor(Node):
    def __init__(self) -> None:
        super().__init__('rescue_safety_monitor')

        # Parámetros principales
        self.declare_parameter('gas_threshold', 50.0)  # usado solo si el String llega como número, ej. '65'
        self.declare_parameter('battery_min', 0.20)
        self.declare_parameter('heartbeat_timeout_sec', 3.0)
        self.declare_parameter('sensor_timeout_sec', 2.5)
        self.declare_parameter('startup_grace_sec', 8.0)
        self.declare_parameter('base_x', 0.0)
        self.declare_parameter('base_y', 0.0)
        self.declare_parameter('base_yaw', 0.0)
        self.declare_parameter('gas_backup_speed', -0.15)
        self.declare_parameter('gas_backup_duration', 2.5)
        self.declare_parameter('heartbeat_spin_speed', 0.5)
        self.declare_parameter('heartbeat_spin_duration', 3.2)
        self.declare_parameter('victim_stop_duration', 5.0)
        self.declare_parameter('thermal_min_intensity', 200)
        self.declare_parameter('thermal_max_intensity', 255)

        # Publicadores
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.alert_pub = self.create_publisher(String, '/rescue/alerts', 10)
        self.state_pub = self.create_publisher(String, '/rescue/safety_state', 10)
        self.victim_pub = self.create_publisher(PoseStamped, '/rescue/victim_location', 10)

        # Suscripciones siempre activas: NO dependen del BT de Nav2
        self.create_subscription(String, '/sensor_gas_critico', self.gas_cb, 10)
        self.create_subscription(String, '/heartbeat', self.heartbeat_cb, 10)
        self.create_subscription(BatteryState, '/battery_status', self.battery_cb, 10)
        self.create_subscription(Bool, '/detected_people', self.visual_cb, 10)
        self.create_subscription(Image, '/thermal_sensor', self.thermal_cb, 10)

        # TF para reportar posición de víctima/robot
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Cliente para cancelar goals de Nav2 aunque este nodo no los haya enviado
        self.cancel_client = self.create_client(
            CancelGoal, '/navigate_to_pose/_action/cancel_goal')
        self.nav_client = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        # Estado de sensores
        self.start_time = self.get_clock().now()
        self.last_gas_time: Optional[Time] = None
        self.last_heartbeat_time: Optional[Time] = None
        self.last_battery_time: Optional[Time] = None
        self.last_visual_time: Optional[Time] = None
        self.last_thermal_time: Optional[Time] = None

        self.gas_message = 'SIN_DATO'
        self.gas_critical = False
        self.battery_fraction = 1.0
        self.person_detected = False
        self.thermal_positive = False

        # Estado de actuación
        self.override_until: Optional[Time] = None
        self.override_cmd = Twist()
        self.last_emergency = 'OK'
        self.return_goal_sent = False
        self.victim_reported = False

        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info(
            '[RescueSafetyMonitor] Activo: sensores vigilados fuera del Behavior Tree de Nav2.')

    # ----------------------------- Callbacks -----------------------------
    def gas_cb(self, msg: String) -> None:
        self.gas_message = msg.data.strip()
        self.gas_critical = self.parse_gas_string(self.gas_message)
        self.last_gas_time = self.get_clock().now()
        self.get_logger().info(
            f'[RescueSafetyMonitor] Leyendo /sensor_gas_critico: "{self.gas_message}" -> '
            f'{"CRÍTICO" if self.gas_critical else "NORMAL"}',
            throttle_duration_sec=1.0
        )

    def parse_gas_string(self, value: str) -> bool:
        normalized = value.strip().upper().replace('Í', 'I')
        normalized = ''.join(normalized.split())
        if normalized in {'CRITICO', 'CRITICAL', 'ALTO', 'HIGH', 'TRUE', '1', 'GAS_CRITICO', 'GASCRITICO'}:
            return True
        if normalized in {'NORMAL', 'OK', 'SEGURO', 'FALSE', '0'}:
            return False
        try:
            return float(normalized) > float(self.get_parameter('gas_threshold').value)
        except ValueError:
            return False

    def heartbeat_cb(self, msg: String) -> None:
        # Cualquier mensaje no vacío se considera heartbeat válido.
        if msg.data.strip():
            self.last_heartbeat_time = self.get_clock().now()

    def battery_cb(self, msg: BatteryState) -> None:
        # Ignora mensajes vacíos/incompletos para no generar falsos positivos.
        if (not msg.present) and float(msg.percentage) <= 0.0 and float(msg.voltage) <= 0.0:
            self.get_logger().warn(
                '[RescueSafetyMonitor] BatteryState incompleto ignorado: present=false, percentage=0, voltage=0.',
                throttle_duration_sec=2.0,
            )
            return

        raw = float(msg.percentage)
        self.battery_fraction = raw / 100.0 if raw > 1.0 else raw
        self.last_battery_time = self.get_clock().now()

    def visual_cb(self, msg: Bool) -> None:
        self.person_detected = bool(msg.data)
        self.last_visual_time = self.get_clock().now()
        if not self.person_detected:
            self.victim_reported = False

    def thermal_cb(self, msg: Image) -> None:
        min_i = int(self.get_parameter('thermal_min_intensity').value)
        max_i = int(self.get_parameter('thermal_max_intensity').value)

        positive = False
        if msg.encoding in ('mono8', '8UC1') and msg.data:
            # msg.data puede llegar como bytes, array o lista de enteros.
            positive = any(min_i <= int(pixel) <= max_i for pixel in msg.data)
        else:
            self.get_logger().warn(
                f'[RescueSafetyMonitor] Frame térmico ignorado: encoding={msg.encoding}',
                throttle_duration_sec=5.0)

        self.thermal_positive = positive
        self.last_thermal_time = self.get_clock().now()

    # ----------------------------- Utilidades -----------------------------
    def age(self, stamp: Optional[Time]) -> Optional[float]:
        if stamp is None:
            return None
        return (self.get_clock().now() - stamp).nanoseconds / 1e9

    def since_start(self) -> float:
        return (self.get_clock().now() - self.start_time).nanoseconds / 1e9

    def publish_alert(self, text: str) -> None:
        msg = String()
        msg.data = text
        self.alert_pub.publish(msg)
        self.get_logger().warn(text, throttle_duration_sec=1.0)

    def publish_state(self, state: str) -> None:
        msg = String()
        msg.data = state
        self.state_pub.publish(msg)

    def stop_robot(self) -> None:
        self.cmd_pub.publish(Twist())

    def cancel_nav2_goals(self) -> None:
        if not self.cancel_client.service_is_ready():
            self.cancel_client.wait_for_service(timeout_sec=0.05)
        if self.cancel_client.service_is_ready():
            # Request vacío: cancela todos los goals según action_msgs/CancelGoal.
            self.cancel_client.call_async(CancelGoal.Request())

    def set_override_motion(self, linear_x: float, angular_z: float, duration: float) -> None:
        cmd = Twist()
        cmd.linear.x = linear_x
        cmd.angular.z = angular_z
        self.override_cmd = cmd
        self.override_until = self.get_clock().now() + Duration(seconds=duration)

    def send_return_to_base(self) -> None:
        if self.return_goal_sent:
            return
        if not self.nav_client.wait_for_server(timeout_sec=0.1):
            self.publish_alert('[BATERÍA] Nav2 todavía no disponible para retorno a base.')
            return

        base_x = float(self.get_parameter('base_x').value)
        base_y = float(self.get_parameter('base_y').value)
        base_yaw = float(self.get_parameter('base_yaw').value)

        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = base_x
        goal.pose.pose.position.y = base_y
        goal.pose.pose.orientation.z = math.sin(base_yaw / 2.0)
        goal.pose.pose.orientation.w = math.cos(base_yaw / 2.0)

        self.nav_client.send_goal_async(goal)
        self.return_goal_sent = True
        self.publish_alert(
            f'[BATERÍA] Retorno a base enviado: x={base_x:.2f}, y={base_y:.2f}.')

    def publish_victim_location(self) -> None:
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()

        try:
            tf = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time(), timeout=Duration(seconds=0.1))
            pose.pose.position.x = tf.transform.translation.x
            pose.pose.position.y = tf.transform.translation.y
            pose.pose.position.z = tf.transform.translation.z
            pose.pose.orientation = tf.transform.rotation
        except Exception as exc:  # noqa: BLE001 - se informa el fallo de TF sin romper el monitor
            self.get_logger().warn(
                f'[VÍCTIMA] No se pudo obtener TF map->base_link: {exc}',
                throttle_duration_sec=2.0)
            return

        self.victim_pub.publish(pose)
        self.victim_reported = True
        self.publish_alert(
            f'[VÍCTIMA] Confirmada. Posición aproximada robot/víctima: '
            f'x={pose.pose.position.x:.2f}, y={pose.pose.position.y:.2f}.')

    # ----------------------------- Lógica principal -----------------------------
    def control_loop(self) -> None:
        now = self.get_clock().now()

        # Si hay una maniobra manual de seguridad en curso, se impone sobre Nav2.
        if self.override_until is not None and now < self.override_until:
            self.cmd_pub.publish(self.override_cmd)
            return
        self.override_until = None

        battery_min = float(self.get_parameter('battery_min').value)
        heartbeat_timeout = float(self.get_parameter('heartbeat_timeout_sec').value)
        sensor_timeout = float(self.get_parameter('sensor_timeout_sec').value)
        startup_grace = float(self.get_parameter('startup_grace_sec').value)

        gas_age = self.age(self.last_gas_time)
        hb_age = self.age(self.last_heartbeat_time)
        bat_age = self.age(self.last_battery_time)
        vis_age = self.age(self.last_visual_time)
        therm_age = self.age(self.last_thermal_time)

        after_grace = self.since_start() > startup_grace

        # Prioridad 1: gas crítico desde /sensor_gas_critico. Siempre cancela navegación y retrocede.
        if gas_age is not None and gas_age <= sensor_timeout and self.gas_critical:
            self.publish_state('GAS_CRITICAL')
            if self.last_emergency != 'GAS_CRITICAL':
                self.cancel_nav2_goals()
                self.publish_alert(
                    f'[GAS] Crítico leído en /sensor_gas_critico: {self.gas_message}. '
                    'Cancelando Nav2 y retrocediendo.')
            self.last_emergency = 'GAS_CRITICAL'
            self.set_override_motion(
                float(self.get_parameter('gas_backup_speed').value),
                0.0,
                float(self.get_parameter('gas_backup_duration').value))
            return

        # Prioridad 2: pérdida de comunicación. Si nunca llegó heartbeat después del grace, también falla.
        link_lost = False
        if after_grace and hb_age is None:
            link_lost = True
        elif hb_age is not None and hb_age > heartbeat_timeout:
            link_lost = True

        if link_lost:
            self.publish_state('HEARTBEAT_LOST')
            if self.last_emergency != 'HEARTBEAT_LOST':
                self.cancel_nav2_goals()
                self.publish_alert('[COMUNICACIÓN] Heartbeat perdido. Cancelando Nav2 y girando para recuperar señal.')
            self.last_emergency = 'HEARTBEAT_LOST'
            self.set_override_motion(
                0.0,
                float(self.get_parameter('heartbeat_spin_speed').value),
                float(self.get_parameter('heartbeat_spin_duration').value))
            return

        # Fallo de sensores críticos: antes se interpretaba como “todo bien”. Ahora se detiene.
        missing_critical_sensor = after_grace and (
            gas_age is None or gas_age > sensor_timeout or
            bat_age is None or bat_age > sensor_timeout
        )
        if missing_critical_sensor:
            self.publish_state('SENSOR_FAULT')
            if self.last_emergency != 'SENSOR_FAULT':
                self.cancel_nav2_goals()
                self.publish_alert('[SENSORES] Falta lectura reciente de /sensor_gas_critico o batería. Robot detenido por seguridad.')
            self.last_emergency = 'SENSOR_FAULT'
            self.stop_robot()
            return

        # Prioridad 3: batería baja. Cancela navegación actual y envía retorno a base.
        if bat_age is not None and bat_age <= sensor_timeout and self.battery_fraction < battery_min:
            self.publish_state('BATTERY_LOW')
            if self.last_emergency != 'BATTERY_LOW':
                self.cancel_nav2_goals()
                self.publish_alert(
                    f'[BATERÍA] Baja: {self.battery_fraction * 100:.1f}% < {battery_min * 100:.1f}%.')
            self.last_emergency = 'BATTERY_LOW'
            # Solo detenemos mientras se envía el goal de retorno. Una vez enviado,
            # dejamos que Nav2 controle /cmd_vel para poder volver realmente a base.
            if not self.return_goal_sent:
                self.stop_robot()
                self.send_return_to_base()
            return

        # Prioridad 4: víctima confirmada visual + térmica. No depende del BT.
        victim_confirmed = (
            self.person_detected and self.thermal_positive and
            vis_age is not None and vis_age <= sensor_timeout and
            therm_age is not None and therm_age <= sensor_timeout
        )
        if victim_confirmed and not self.victim_reported:
            self.publish_state('VICTIM_CONFIRMED')
            self.cancel_nav2_goals()
            self.stop_robot()
            self.publish_victim_location()
            self.set_override_motion(
                0.0,
                0.0,
                float(self.get_parameter('victim_stop_duration').value))
            self.last_emergency = 'VICTIM_CONFIRMED'
            return

        # Estado normal.
        if self.last_emergency != 'OK':
            self.publish_alert('[SEGURIDAD] Condiciones normalizadas. Monitor activo.')
        self.last_emergency = 'OK'
        self.publish_state('OK')


def main(args=None) -> None:
    rclpy.init(args=args)
    node = RescueSafetyMonitor()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
