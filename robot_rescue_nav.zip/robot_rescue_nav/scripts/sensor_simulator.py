#!/usr/bin/env python3
"""
Simulador de sensores para robot de búsqueda y rescate.

Tópicos oficiales del proyecto:
- /sensor_gas_critico : std_msgs/String  -> "NORMAL" o "CRITICO"
- /heartbeat          : std_msgs/String  -> "Control_Center_OK"
- /battery_status     : sensor_msgs/BatteryState
- /detected_people    : std_msgs/Bool
- /thermal_sensor     : sensor_msgs/Image

Nota: se eliminó la publicación automática de /gas_sensor para evitar doble
fuente de gas. La condición oficial del árbol debe leer solo /sensor_gas_critico.
"""

import math

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from sensor_msgs.msg import BatteryState, Image
from std_msgs.msg import Bool, String


class SensorSimulator(Node):
    def __init__(self):
        super().__init__('sensor_simulator')

        # Parámetros editables desde launch/terminal.
        self.declare_parameter('heartbeat_value', 'Control_Center_OK')
        self.declare_parameter('normal_gas_value', 'NORMAL')
        self.declare_parameter('critical_gas_value', 'CRITICO')
        self.declare_parameter('gas_radius', 1.0)
        self.declare_parameter('victim_radius', 1.0)
        self.declare_parameter('gas_leak_x', 1.5)
        self.declare_parameter('gas_leak_y', 1.0)
        self.declare_parameter('victim_x', 2.5)
        self.declare_parameter('victim_y', -2.0)
        self.declare_parameter('battery_initial_percent', 100.0)
        self.declare_parameter('battery_drain_percent_per_sec', 0.1)

        self.heartbeat_value = str(self.get_parameter('heartbeat_value').value)
        self.normal_gas_value = str(self.get_parameter('normal_gas_value').value)
        self.critical_gas_value = str(self.get_parameter('critical_gas_value').value)

        self.gas_radius = float(self.get_parameter('gas_radius').value)
        self.victim_radius = float(self.get_parameter('victim_radius').value)
        self.gas_leak_pos = (
            float(self.get_parameter('gas_leak_x').value),
            float(self.get_parameter('gas_leak_y').value),
        )
        self.victim_pos = (
            float(self.get_parameter('victim_x').value),
            float(self.get_parameter('victim_y').value),
        )

        # Publicadores oficiales de las reglas del proyecto.
        self.gas_critico_pub = self.create_publisher(String, '/sensor_gas_critico', 10)
        self.heartbeat_pub = self.create_publisher(String, '/heartbeat', 10)
        self.vis_pub = self.create_publisher(Bool, '/detected_people', 10)
        self.therm_pub = self.create_publisher(Image, '/thermal_sensor', 10)
        self.battery_pub = self.create_publisher(BatteryState, '/battery_status', 10)

        # Suscriptor para conocer la posición del robot.
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)

        self.robot_x = 0.0
        self.robot_y = 0.0
        self.battery_level = float(self.get_parameter('battery_initial_percent').value)

        # Timers de publicación.
        self.create_timer(0.5, self.publish_environmental_sensors)
        self.create_timer(1.0, self.publish_systems)

        self.get_logger().info(
            '[SensorSimulator] Publicadores oficiales activos: '
            '/heartbeat="%s", /sensor_gas_critico={%s,%s}' % (
                self.heartbeat_value,
                self.normal_gas_value,
                self.critical_gas_value,
            )
        )

    def odom_callback(self, msg):
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y

    def publish_environmental_sensors(self):
        dist_to_gas = math.hypot(
            self.robot_x - self.gas_leak_pos[0],
            self.robot_y - self.gas_leak_pos[1],
        )
        dist_to_victim = math.hypot(
            self.robot_x - self.victim_pos[0],
            self.robot_y - self.victim_pos[1],
        )

        # Regla 1: Gas tóxico usando el tópico unificado obligatorio.
        gas_state_msg = String()
        gas_state_msg.data = (
            self.critical_gas_value if dist_to_gas < self.gas_radius else self.normal_gas_value
        )
        self.gas_critico_pub.publish(gas_state_msg)
        self.get_logger().info(
            f'[SensorSimulator] /sensor_gas_critico = {gas_state_msg.data}',
            throttle_duration_sec=1.0,
        )

        # Regla 4: Víctima y sensor térmico simulados.
        vis_msg = Bool()
        therm_msg = Image()
        therm_msg.header.stamp = self.get_clock().now().to_msg()
        therm_msg.height = 240
        therm_msg.width = 320
        therm_msg.step = 320
        therm_msg.encoding = 'mono8'

        if dist_to_victim < self.victim_radius:
            vis_msg.data = True
            therm_msg.data = [255] * (320 * 240)
        else:
            vis_msg.data = False
            therm_msg.data = [0] * (320 * 240)

        self.vis_pub.publish(vis_msg)
        self.therm_pub.publish(therm_msg)

    def publish_systems(self):
        # Regla 2: Heartbeat oficial del centro de control.
        hb_msg = String()
        hb_msg.data = self.heartbeat_value
        self.heartbeat_pub.publish(hb_msg)

        # Regla 3: Batería simulada.
        drain = float(self.get_parameter('battery_drain_percent_per_sec').value)
        self.battery_level = max(0.0, self.battery_level - drain)

        bat_msg = BatteryState()
        bat_msg.header.stamp = self.get_clock().now().to_msg()
        bat_msg.header.frame_id = 'base_link'

        # El proyecto acepta 0-100; CheckBatteryCondition normaliza a 0-1.
        # Se llena el mensaje completo para evitar que Nav2/BT interprete
        # present=false, voltage=0.0, percentage=0.0 como batería crítica falsa.
        bat_msg.percentage = self.battery_level
        bat_msg.voltage = 12.6 * (self.battery_level / 100.0)
        bat_msg.temperature = 25.0
        bat_msg.current = 0.0
        bat_msg.charge = self.battery_level / 100.0
        bat_msg.capacity = 1.0
        bat_msg.design_capacity = 1.0
        bat_msg.power_supply_status = BatteryState.POWER_SUPPLY_STATUS_DISCHARGING
        bat_msg.power_supply_health = BatteryState.POWER_SUPPLY_HEALTH_GOOD
        bat_msg.power_supply_technology = BatteryState.POWER_SUPPLY_TECHNOLOGY_LION
        bat_msg.present = True

        self.battery_pub.publish(bat_msg)

        if self.battery_level <= 20.0:
            self.get_logger().warn(
                f'[SensorSimulator] BATERÍA CRÍTICA: {self.battery_level:.1f}%',
                throttle_duration_sec=5.0,
            )


def main(args=None):
    rclpy.init(args=args)
    node = SensorSimulator()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
