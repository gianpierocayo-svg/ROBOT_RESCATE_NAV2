# Pruebas rápidas - Robot Rescue Nav

## 1) Configurar dominio ROS
Ejecutar en TODAS las terminales:

```bash
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=4
source install/setup.bash
```

Verificar:

```bash
echo $ROS_DOMAIN_ID
```

Debe responder:

```text
4
```

## 2) Compilar limpio

```bash
cd ~/ros2_ws
rm -rf build/robot_rescue_nav install/robot_rescue_nav log
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=4
colcon build --packages-select robot_rescue_nav --symlink-install
source install/setup.bash
```

## 3) Lanzar proyecto

```bash
ros2 launch robot_rescue_nav rescue_navigation.launch.py
```

En RViz, primero usar **2D Pose Estimate** para ubicar el robot. Después usar **Nav2 Goal**.

## 4) Ver tópicos activos

```bash
ros2 topic list
```

Deben aparecer, entre otros:

```text
/sensor_gas_critico
/heartbeat
/battery_status
/detected_people
/thermal_sensor
/cmd_vel
/odom
/scan
```

## 5) Verificar publicación y lectura de sensores

```bash
ros2 topic echo /sensor_gas_critico --once
ros2 topic echo /heartbeat --once
ros2 topic echo /battery_status --once
ros2 topic echo /detected_people --once
```

Valores normales esperados:

```text
/sensor_gas_critico -> data: NORMAL
/heartbeat -> data: Control_Center_OK
/battery_status -> present: true, percentage mayor a 20.0 o 0.20
/detected_people -> data: false
```

## 6) Verificar que el árbol lee los tópicos
Al mandar un goal, la consola del launch debe mostrar mensajes como:

```text
[CheckGasCondition] Recibido /sensor_gas_critico: 'NORMAL' -> NORMAL
[CheckGasCondition] Leyendo /sensor_gas_critico: 'NORMAL' -> gas normal
[CheckHeartbeatCondition] Primer heartbeat recibido
[CheckBatteryCondition] Leyendo /battery_status
```

## 7) Probar gas crítico manualmente

```bash
ros2 topic pub -r 1 /sensor_gas_critico std_msgs/msg/String "{data: 'CRITICO'}"
```

Para volver a normal:

```bash
ros2 topic pub -r 1 /sensor_gas_critico std_msgs/msg/String "{data: 'NORMAL'}"
```

## 8) Ver movimiento del robot

```bash
ros2 topic echo /cmd_vel
```

Con un goal normal, debe aparecer velocidad lineal y/o angular. Si solo aparece giro, revisar primero pose inicial de AMCL en RViz con **2D Pose Estimate**.
